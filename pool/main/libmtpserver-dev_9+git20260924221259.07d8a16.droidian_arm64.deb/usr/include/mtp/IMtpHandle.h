/*
 * Copyright (C) 2016 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

#ifndef _I_MTP_HANDLE_H
#define _I_MTP_HANDLE_H

#include <stddef.h>
#include <stdint.h>
#include <sys/types.h>
#include "linux/usb/f_mtp.h"

namespace android {

class IMtpHandle {
public:
    virtual ~IMtpHandle() {}
    virtual int configure(bool ptp) = 0;
    virtual int start(bool ptp) = 0;
    virtual int read(void* data, size_t len) = 0;
    virtual int write(const void* data, size_t len) = 0;
    virtual int receiveFile(const mtp_file_range& mfr, bool zeroPacket) = 0;
    virtual int sendFile(const mtp_file_range& mfr) = 0;
    virtual int sendEvent(const mtp_event& event) = 0;
    virtual void close() = 0;
    virtual bool isFunctionFs() const = 0;
};

IMtpHandle* createMtpDevHandle(const char* path = "/dev/mtp_usb");
IMtpHandle* createMtpDevHandleFromFd(int fd);
IMtpHandle* createMtpFfsHandle(const char* path = "/dev/usb-ffs/mtp");

} // namespace android

#endif // _I_MTP_HANDLE_H
