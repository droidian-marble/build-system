#!/bin/bash

# On systems with A/B partition layout, current slot is provided via cmdline parameter.
if [ -e /proc/bootconfig ]; then
    ab_slot_suffix=$(grep -o 'androidboot\.slot_suffix = ".."' /proc/bootconfig | cut -d '"' -f2)
fi

if [ -z "$ab_slot_suffix" ]; then
    ab_slot_suffix=$(grep -o 'androidboot\.slot_suffix=..' /proc/cmdline |  cut -d "=" -f2)
fi

[ ! -z "$ab_slot_suffix" ] && echo "A/B slot system detected! Slot suffix is $ab_slot_suffix"

find_partition_path() {
    label=$1
    path="/dev/$label"
    # In case fstab provides /dev/mmcblk0p* lines
    for dir in by-partlabel by-name by-label by-path by-uuid by-partuuid by-id; do
        # On A/B systems not all of the partitions are duplicated, so we have to check with and without suffix
        if [ -b "/dev/disk/$dir/$label$ab_slot_suffix" ]; then
            path="/dev/disk/$dir/$label$ab_slot_suffix"
            break
        elif [ -b "/dev/disk/$dir/$label" ]; then
            path="/dev/disk/$dir/$label"
            break
        fi
    done

    if [ ! -b "$path" ]; then
        if [ -b "/dev/mapper/dynpart-$label$ab_slot_suffix" ]; then
            path="/dev/mapper/dynpart-$label$ab_slot_suffix"
        elif [ -b "/dev/mapper/dynpart-$label" ]; then
            path="/dev/mapper/dynpart-$label"
        elif [ -b "/dev/mapper/dynpart-${label}_a" ] && [ ! -b "/dev/mapper/dynpart-${label}_b" ]; then
            path="/dev/mapper/dynpart-${label}_a"
        elif [ -b "/dev/mapper/dynpart-${label}_b" ] && [ ! -b "/dev/mapper/dynpart-${label}_a" ]; then
            path="/dev/mapper/dynpart-${label}_b"
        fi
    fi

    echo $path
}

parse_mount_flags() {
    org_options="$1"
    options=""
    for i in $(echo $org_options | tr "," "\n"); do
        [[ "$i" =~ context|trusted ]] && continue
        options+=$i","
    done
    options=${options%?}
    echo $options
}

if [ -n "${BIND_MOUNT_PATH}" ] && ! mountpoint -q -- "${BIND_MOUNT_PATH}"; then
    android_images="/userdata/android-rootfs.img /var/lib/lxc/android/android-rootfs.img"
    for image in ${android_images}; do
        if [ -f "${image}" ]; then
            mount "${image}" "${BIND_MOUNT_PATH}"
            break
        fi
    done
fi

if [ -e "/dev/disk/by-partlabel/super" ]; then
    echo "mapping super partition"
    dmsetup create --concise "$(parse-android-dynparts /dev/disk/by-partlabel/super)"
fi

if [ ! -e "/vendor/build.prop" ]; then
    echo "checking for vendor mount point"
    vendor_images="/userdata/vendor.img /var/lib/lxc/android/vendor.img /dev/disk/by-partlabel/vendor${ab_slot_suffix} /dev/disk/by-partlabel/vendor_a /dev/disk/by-partlabel/vendor_b /dev/mapper/dynpart-vendor /dev/mapper/dynpart-vendor${ab_slot_suffix} /dev/mapper/dynpart-vendor_a /dev/mapper/dynpart-vendor_b"
    for image in $vendor_images; do
        if [ -e $image ]; then
            echo "mounting vendor from $image"
            mount $image /vendor -o ro

            if [ -e "/vendor/build.prop" ]; then
                echo "found valid vendor partition: $image"
                break
            else
                echo "$image is not a valid vendor partition"
                umount /vendor
            fi
        fi
    done
fi

if [ ! -e "/vendor_dlkm/etc/build.prop" ]; then
    echo "checking for vendor_dlkm mount point"
    vendor_dlkm_images="/dev/mapper/dynpart-vendor_dlkm /dev/mapper/dynpart-vendor_dlkm${ab_slot_suffix} /dev/mapper/dynpart-vendor_dlkm_a /dev/mapper/dynpart-vendor_dlkm_b"
    for image in $vendor_dlkm_images; do
        if [ -e $image ]; then
            echo "mounting vendor_dlkm from $image"
            mount $image /vendor_dlkm -o ro

            if [ -e "/vendor_dlkm/etc/build.prop" ]; then
                echo "found valid vendor_dlkm partition: $image"
                break
            else
                echo "$image is not a valid vendor_dlkm partition"
                umount /vendor_dlkm
            fi
        fi
    done
fi

sys_vendor="/sys/firmware/devicetree/base/firmware/android/fstab/vendor"
if [ -e $sys_vendor ] && ! mountpoint -q -- /vendor; then
    label=$(cat $sys_vendor/dev | awk -F/ '{print $NF}')
    path=$(find_partition_path $label)
    [ ! -e "$path" ] && echo "Error vendor not found" && exit
    type=$(cat $sys_vendor/type)
    options=$(parse_mount_flags $(cat $sys_vendor/mnt_flags))
    echo "mounting $path as /vendor"
    mount $path /vendor -t $type -o $options
fi

# Bind-mount /vendor if we should. Legacy devices do not have /vendor
# on a separate partition and we should handle that.
if [ -n "${BIND_MOUNT_PATH}" ] && mountpoint -q -- /vendor; then
    # Mountpoint, bind-mount. We don't use rbind as we're going
    # to go through the fstab anyways.
    mount -o bind /vendor "${BIND_MOUNT_PATH}/vendor"
fi

sys_persist="/sys/firmware/devicetree/base/firmware/android/fstab/persist"
if [ -e $sys_persist ]; then
    label=$(cat $sys_persist/dev | awk -F/ '{print $NF}')
    path=$(find_partition_path $label)
    # [ ! -e "$path" ] && echo "Error persist not found" && exit
    type=$(cat $sys_persist/type)
    options=$(parse_mount_flags $(cat $sys_persist/mnt_flags))
    echo "mounting $path as /mnt/vendor/persist"
    mount $path /mnt/vendor/persist -t $type -o $options
fi

echo "checking if system overlay exists"
if [ -d "/usr/lib/droid-system-overlay" ]; then
    echo "mounting android's system overlay"
    if [ $(uname -r | cut -d "." -f 1) -ge "4" ]; then
        mount -t overlay overlay -o lowerdir=/usr/lib/droid-system-overlay:/var/lib/lxc/android/rootfs/system /var/lib/lxc/android/rootfs/system
        echo "overlayed on /var/lib/lxc/android/rootfs/system"
        if [ -d "/android/system" ]; then
            mount -t overlay overlay -o lowerdir=/usr/lib/droid-system-overlay:/android/system /android/system
            echo "overlayed on /android/system"
        fi
    else
        mount -t overlay overlay -o lowerdir=/var/lib/lxc/android/rootfs/system,upperdir=/usr/lib/droid-system-overlay,workdir=/var/lib/lxc/android/ /var/lib/lxc/android/rootfs/system
        echo "overlayed on /var/lib/lxc/android/rootfs/system"
        if [ -d "/android/system" ]; then
            mount -t overlay overlay -o lowerdir=/android/system,upperdir=/usr/lib/droid-system-overlay,workdir=/android/ /android/system
            echo "overlayed on /android/system"
        fi
    fi
fi

echo "checking if vendor overlay exists"
if [ -d "/usr/lib/droid-vendor-overlay" ]; then
    echo "mounting android's vendor overlay"
    if [ $(uname -r | cut -d "." -f 1) -ge "4" ]; then
        mount -t overlay overlay -o lowerdir=/usr/lib/droid-vendor-overlay:/var/lib/lxc/android/rootfs/vendor /var/lib/lxc/android/rootfs/vendor
    else
        mount -t overlay overlay -o lowerdir=/var/lib/lxc/android/rootfs/vendor,upperdir=/usr/lib/droid-vendor-overlay,workdir=/var/lib/lxc/android/ /var/lib/lxc/android/rootfs/vendor
    fi
fi

# Assume there's only one fstab in vendor
set -- /vendor/etc/fstab*
[ ! -e "$1" ] && echo "fstab not found" && exit 1
fstab=$1

echo "checking fstab $fstab for additional mount points"

cat ${fstab} ${EXTRA_FSTAB} | while read line; do
    set -- $line

    case $1 in
        \#endhalium*) break ;; # stop processing if we hit the "#endhalium" comment in the file
        \#*|"") continue ;; # Skip any unwanted entry
    esac

    ([ -z "$1" ] || [ -z "$2" ] || [ -z "$3" ] || [ -z "$4" ]) && continue

    case $2 in
        /system|/data|/|auto|/vendor|none|/misc|/system_ext|/product) continue ;;
    esac

    case $3 in
        emmc|swap|mtd) continue ;;
    esac

    label=${1##*/}
    [ -z "$label" ] && continue

    echo "checking mount label $label"

    path=$(find_partition_path $label)

    [ ! -e "$path" ] && continue

    mkdir -p $2
    echo "mounting $path as $2"
    mount $path $2 -t $3 -o $(parse_mount_flags $4)

    # Bind mount on rootfs if we should
    if [ -n "${BIND_MOUNT_PATH}" ] && [[ ${2} != /mnt/* ]]; then
        # /mnt is recursively binded via the LXC configuration
        mount -o bind ${2} "${BIND_MOUNT_PATH}/${2}"
    fi
done

# Prepare the host APEX tree before it is bind-mounted into the container.
if [ -e /apex ]; then
    if ! mountpoint -q -- /apex; then
        echo "mounting tmpfs on /apex"
        mount -t tmpfs tmpfs /apex
    fi

    echo "finding and mounting APEXs"
    /usr/sbin/droidian-apex mount --all
fi
